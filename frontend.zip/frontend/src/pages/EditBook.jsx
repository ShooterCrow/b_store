import React from 'react'

const EditBook = () => {
  return (
    <div>EditBook</div>
  )
}

export default EditBook